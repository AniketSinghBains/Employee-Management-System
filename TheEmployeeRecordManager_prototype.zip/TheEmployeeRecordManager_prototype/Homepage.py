from tkinter import messagebox, ttk
from tkinter import *
from PIL import ImageTk,Image
import detailspage as dp
class HomepageClass:
    def __init__(self, username, usertype):
        self.username = username
        self.usertype = usertype
        self.window = Tk()
        self.window.title(dp.app_title_name)
        self.w = self.window.winfo_screenwidth()
        self.h = self.window.winfo_screenheight()
        self.window.minsize(self.w,self.h)
        self.window.state('zoomed')

        # -------- frames ------------
        self.f1_height=80
        self.f2_height=self.h-self.f1_height
        self.window.config(background='white')

        self.bklbl_win = Label(self.window,background='pink')
        # self.img1_win = Image.open("app_images//blue_bg3.jpg").resize((int(self.w), self.f2_height))
        # self.img2_win = ImageTk.PhotoImage(self.img1_win)
        # self.bklbl_win.config(image=self.img2_win)
        self.bklbl_win.place(x=-2, y=self.f1_height-2)

        self.f1 = Frame(self.window, background=dp.my_color2)  # heading
        self.f21 = Frame(self.window, background='red')  #  logo
        self.f22 = Frame(self.window, background='green')  #  logo
        self.f3 = Frame(self.window, background='white')  #  button
        self.f4 = Frame(self.window, background='white')  # content pane

        self.f1.place(x=0, y=0, height=self.f1_height, width=self.w)  # heading
        # self.f3.place(x=0, y=self.f1_height, height=self.f2_height, width=self.w)  # buttons page
        # self.f21.place(x=0, y=self.f1_height, height=self.f2_height, width=int(self.w/2))  # logo page
        self.f21.place(x=self.w, y=self.f1_height, height=self.f2_height, width=self.w+200)  # logo page
        # self.f22.place(x=self.w/2, y=self.f1_height, height=self.f2_height, width=int(self.w/2))  # logo page
        # self.f4.place(x=0, y=self.f1_height, height=self.f2_height, width=self.w)  # content page
        # -----------------------------

        # -------frame 1's content(heading)-----------
        self.headlbl = Label(self.window, text=dp.app_title_name, font=dp.myheadfont1,
                             background=dp.my_color2,foreground='white', justify='center')
        self.headlbl.place(x=200, y=3)


        self.cpassword_btn_img = Image.open("app_images//white_password1.png").resize((40,40))
        self.cpassword_btn_img = ImageTk.PhotoImage(self.cpassword_btn_img)
        self.cpassword_btn = Button(self.window, background=dp.my_color2,
                          compound=TOP,relief='flat',image=self.cpassword_btn_img)
        self.cpassword_btn.place(x=self.w-100, y=20, width=50, height=50)

        self.log_btn_img = Image.open("app_images//white_logout1.png").resize((40,40))
        self.log_btn_img = ImageTk.PhotoImage(self.log_btn_img)
        self.log_btn = Button(self.window, background=dp.my_color2, command=self.quitter,
                          compound=TOP,relief='flat',image=self.log_btn_img)
        self.log_btn.place(x=self.w-50, y=20, width=50, height=50)
        # ------------------------------------------
        # ----------- frame 21 and 22 (logo page) ------------------------
        self.bklbl = Label(self.f21)
        # self.img1 = Image.open("app_images//blue_bg5.png").resize((int(self.w/2), self.f2_height))
        self.img1 = Image.open("app_images//employee_success.png").resize((int(self.w+200), self.f2_height))
        self.img2 = ImageTk.PhotoImage(self.img1)
        self.bklbl.config(image=self.img2)
        self.bklbl.place(x=-2, y=-2)

        self.bklblf2 = Label(self.f22)
        self.img1f2 = Image.open("app_images//blue_bg6.jpg").resize((int(self.w/2), self.f2_height))
        self.img2f2 = ImageTk.PhotoImage(self.img1f2)
        self.bklblf2.config(image=self.img2f2)
        self.bklblf2.place(x=-2, y=-2)
        #-------------------------------------------- ----

        # -------frame 3's content(buttons page)-----------
        self.bklbl2 = Label(self.f3)
        self.img12 = Image.open("app_images//blue_bg.jpg").resize((self.w, self.f2_height))
        self.img22 = ImageTk.PhotoImage(self.img12)
        self.bklbl2.config(image=self.img22)
        self.bklbl2.place(x=-10, y=-10)



        btn_color = dp.my_color2
        btn_fg_color = 'white'
        self.btn_border='raise'
        self.bw=9

        self.img_size=60
        self.b1_img= Image.open("app_images//white_department.png").resize((self.img_size,self.img_size))
        self.b1_img = ImageTk.PhotoImage(self.b1_img)
        self.b1 = Button(self.f3, text='Department', foreground=btn_fg_color, background=btn_color, font=dp.mynormalfont,
                         command=self.open_department_page,compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b1_img)


        self.b2_img= Image.open("app_images//white_designation.png").resize((self.img_size,self.img_size))
        self.b2_img = ImageTk.PhotoImage(self.b2_img)
        self.b2 = Button(self.f3, text='Designation', foreground=btn_fg_color, background=btn_color, font=dp.mynormalfont,
                         command=self.open_designation_page,compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b2_img)


        self.b3_img= Image.open("app_images//white_employees.png").resize((self.img_size,self.img_size))
        self.b3_img = ImageTk.PhotoImage(self.b3_img)
        self.b3 = Button(self.f3, text='Employee', foreground=btn_fg_color, background=btn_color, font=dp.mynormalfont,
                       compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b3_img)


        self.b4_img= Image.open("app_images//white_employeeReport.png").resize((self.img_size,self.img_size))
        self.b4_img = ImageTk.PhotoImage(self.b4_img)
        self.b4 = Button(self.f3, text='Employee Table', foreground=btn_fg_color, background=btn_color, font=dp.mynormalfont,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b4_img)

        self.b5_img= Image.open("app_images//white_attendence.png").resize((self.img_size,self.img_size))
        self.b5_img = ImageTk.PhotoImage(self.b5_img)
        self.b5 = Button(self.f3, text='Employee \nAttendence', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b5_img)

        self.b6_img= Image.open("app_images//white_salary_growth.png").resize((self.img_size,self.img_size))
        self.b6_img = ImageTk.PhotoImage(self.b6_img)
        self.b6 = Button(self.f3, text='Pay Head', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b6_img)

        self.b7_img= Image.open("app_images//white_moneyconnection.png").resize((self.img_size,self.img_size))
        self.b7_img = ImageTk.PhotoImage(self.b7_img)
        self.b7 = Button(self.f3, text='Create Salary', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b7_img)

        self.b8_img= Image.open("app_images//white_salary.png").resize((self.img_size,self.img_size))
        self.b8_img = ImageTk.PhotoImage(self.b8_img)
        self.b8 = Button(self.f3, text='Manage Salary', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b8_img)

        self.b9_img= Image.open("app_images//white_user1.png").resize((self.img_size,self.img_size))
        self.b9_img = ImageTk.PhotoImage(self.b9_img)
        self.b9 = Button(self.f3, text='Manage User', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont,command=self.open_user_page,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b9_img)

        self.b10_img= Image.open("app_images//white_report1.png").resize((self.img_size,self.img_size))
        self.b10_img = ImageTk.PhotoImage(self.b10_img)
        self.b10 = Button(self.f3, text='Salary Report', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont ,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b10_img)

        self.b11_img= Image.open("app_images//white_report2.png").resize((self.img_size,self.img_size))
        self.b11_img = ImageTk.PhotoImage(self.b11_img)
        self.b11 = Button(self.f3, text='Employee Report', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont ,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b11_img)


        self.b12_img= Image.open("app_images//white_report3.png").resize((self.img_size,self.img_size))
        self.b12_img = ImageTk.PhotoImage(self.b12_img)
        self.b12 = Button(self.f3, text='Attendence \nReport', foreground=btn_fg_color, background=btn_color,
                         font=dp.mynormalfont,
                         compound=TOP,relief=self.btn_border,borderwidth=self.bw,image=self.b12_img)


        if (self.w >= 1600):
            startx=310
            self.btn_height = 240
            self.btn_width=260
            self.btn_hgap = self.btn_width+5
            self.btn_vgap = self.btn_height+5
            start_y=10
        elif (self.w >= 1300):
            startx=300
            self.btn_height = 200
            self.btn_width=200
            self.btn_hgap = self.btn_width+5
            self.btn_vgap = self.btn_height+5
            start_y=10
        else:
            startx = 350
            self.btn_height = 200
            self.btn_width=200
            self.btn_hgap = self.btn_width+5
            self.btn_vgap = self.btn_height+5
            start_y = 30

        if self.usertype == 'Admin':
            #------ row 1 ----------
            self.x1 = startx
            self.y1 = start_y

            self.b1.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b2.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b3.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b4.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap

            # ------ row 2 ----------
            self.y1 += self.btn_vgap
            self.x1 = startx
            self.b5.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b6.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b7.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b8.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap

            # ------ row 3 ----------
            self.y1 += self.btn_vgap
            self.x1 = startx
            self.b9.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b10.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b11.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b12.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap

        else:
            startx+=100
            start_y+=100
            #------ row 1 ----------
            self.x1 = startx
            self.y1 = start_y

            self.b2.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b3.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b4.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap

            # ------ row 2 ----------
            self.y1 += self.btn_vgap
            self.x1 = startx
            self.b5.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b11.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap
            self.b12.place(x=self.x1, y=self.y1, height=self.btn_height, width=self.btn_width)
            self.x1 += self.btn_hgap





        self.f3.place(x=0, y=self.f1_height, height=self.f2_height, width=self.w)  # buttons page


        self.window.mainloop()


    def quitter(self):
        ans = messagebox.askquestion("Confirmation", "Are you sure to Logout ? ", parent=self.window)
        if ans == 'yes':
            self.window.destroy()
            from loginpage import LoginPageClass
            LoginPageClass()

    def open_department_page(self):
        self.clear_frame()
        from ManageDepartment import ManageDepartmentClass
        ManageDepartmentClass(self.f4)

    def open_designation_page(self):
        self.clear_frame()
        from ManageDesignation import ManageDesignationClass
        ManageDesignationClass(self.f4)




    def open_user_page(self):
        self.clear_frame()
        from ManageUser import ManageUserClass
        ManageUserClass(self.f4)



    def clear_frame(self):
        for widget in self.f4.winfo_children():
            widget.destroy()
        self.main_bk=Label(self.f4)
        self.img_folded= Image.open("app_images//blue_bg7_3.jpg").resize((self.w, self.f2_height))
        self.img_folded = ImageTk.PhotoImage(self.img_folded)
        self.main_bk.config(image=self.img_folded)
        self.main_bk.place(x=-10,y=-10)
        self.f4.place(x=0, y=self.f1_height, height=self.f2_height +25, width=self.w)  # content page


if __name__ == '__main__':
    obj = HomepageClass("admin",'Admin')

