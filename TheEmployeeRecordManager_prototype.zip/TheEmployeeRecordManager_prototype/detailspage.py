
app_title_name = 'Employee Record Management System'
contact = "98989898"

myhost = 'localhost'
mydb = "the_employee_mgt_db"
myuser = 'root'
mypassword = ''
default_emp_pic_img = 'default_user.png'
default_emp_proof_img = 'noimage.jpg'
# default_stu_img = 'default_user.png'

my_color1 = "#F3F6FF"#'#FFFFFF'   # (light color) - content background (all pages color)
my_color2 = '#2B48FF'   # (ok shade)     -   Frame's btn and heading background
my_color3 = '#2B48FF'  # (dark shade)  -   btn Frame background
my_color4 = '#0729FF' # all pages btn
# my_color4 = '#C60A35' # all pages btn

all_pages_bk = my_color1
table_row_bk_color1 = my_color1
# table_row_bk_color1 = my_color1
table_row_fg_color1 = 'black'
table_row_bk_color2 = "#add2ff"
# table_row_bk_color2 = my_color2
table_row_fg_color2 = 'black'
all_btn_bk_color=my_color4
all_btn_fg_color=my_color1

isAdmin=True
myheadfont = ('Century', 34, 'bold')
myheadfont1 = ('Century', 45, 'bold')
mynormalfont = ('Century', 14, 'bold')
myfont_subhead = ('Century', 17, 'bold')
myfont_subhead2 = ('Century', 17, 'bold')