from tkinter import *
from tkinter import messagebox
import pymysql
from PIL import ImageTk,Image
import detailspage as dp
class LoginPageClass:
    def __init__(self):
        self.window=Tk()
        self.window.title(dp.app_title_name+"//Login")
        my_color4 = '#694F87'
        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        win_width = int(w -800)
        win_height=int(h-400)
        self.window.minsize(win_width, win_height)
        self.window.maxsize(win_width,win_height)
        self.window.geometry("%dx%d+%d+%d" % (win_width,win_height, 400, 200))

        self.bklbl=Label(self.window)
        self.img1 = Image.open("app_images//ppt_img2.jpg").resize((win_width+2,win_height-40))
        self.img2 = ImageTk.PhotoImage(self.img1)
        self.bklbl.config(image=self.img2)
        self.bklbl.place(x=-2,y=40)


        lblw=win_width
        self.headlbl = Label(self.window, text='Employee Management System',
                             font=dp.myheadfont, background=dp.my_color2,foreground='white',
                             relief='raised',borderwidth=5)
        self.headlbl.place(x=0,y=-2,width=lblw)



        bk_color = 'white'
        self.f1 = Frame(self.window, background=bk_color)
        #------------- Making widgets--------------
        if (w >= 1600):
            myfont = ('Century', 14, 'bold')
            frame_width = 360
            frame_height = 140
            self.f1.place(x=225, y=120, height=frame_height, width=frame_width)
        elif (w>=1360):
            myfont = ('Century',12, 'bold')
            frame_width = 260
            frame_height = 110
            self.f1.place(x=160, y=100, height=frame_height, width=frame_width)
        else:
            myfont = ('Century',12, 'bold')
            frame_width = 260
            frame_height = 110
            self.f1.place(x=160, y=100, height=frame_height, width=frame_width)

        self.l1=Label(self.f1,text='User Name',font=myfont,background=bk_color)
        self.l2=Label(self.f1,text='Password',font=myfont,background=bk_color)

        self.t1=Entry(self.f1,font=myfont,background=bk_color)
        self.t2=Entry(self.f1,font=myfont,show='*',background=bk_color)

        self.t2.bind("<Return>",lambda e: self.checkdata())
        #------ buttons---------

        self.b1=Button(self.f1,text='Let me in !!!',font=myfont ,
                       background=dp.my_color4,
                       foreground='white',command=self.checkdata)

        #---------------placements-----------------

        if(w>=1600):
            xdiff=130
            ydiff=40
            x1 = 10
            y1 = 10
            widget_width=200
        elif w>=1360:
            xdiff=100
            ydiff=30
            x1 = 20
            y1 = 10
            widget_width=130
        else:
            xdiff=100
            ydiff=30
            x1 = 20
            y1 = 10
            widget_width=130
        self.l1.place(x=x1,y=y1 )
        self.t1.place(x=x1+xdiff,y=y1,width=widget_width)

        y1+=ydiff
        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1+xdiff,y=y1,width=widget_width)

        y1+=ydiff
        self.b1.place(x=x1+xdiff,y=y1,width=widget_width)

        self.window.mainloop()

    def databaseconnection(self):
        try:
            self.conn = pymysql.connect(host=dp.myhost,db=dp.mydb,user=dp.myuser,password=dp.mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error","Error while connecting with database\n\n"+str(e),parent=self.window)

    def checkdata(self):
        self.databaseconnection()
        try:
            myqry='select * from  usertable where username=%s and password=%s'
            self.curr.execute(myqry,(self.t1.get(),self.t2.get()))
            data=self.curr.fetchone()
            if data:
                un=data[0]
                ut=data[2]
                if ut=='Admin':
                    dp.isAdmin=True
                else:
                    dp.isAdmin=False
                self.window.destroy()
                from Homepage import HomepageClass
                HomepageClass(un,ut)
            else:
                messagebox.showinfo("Error", "Incorrect Username or password ",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error","Error while Insertion of record\n\n"+str(e),parent=self.window)

if __name__ == '__main__':
    obj = LoginPageClass()



