-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2024 at 10:15 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `the_employee_mgt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendancetable`
--

CREATE TABLE `attendancetable` (
  `srno` int(10) NOT NULL,
  `att_date` date NOT NULL,
  `empid` int(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendancetable`
--

INSERT INTO `attendancetable` (`srno`, `att_date`, `empid`, `name`, `department`, `status`) VALUES
(85, '2024-01-01', 1, 'ishan', '1', 'Present'),
(86, '2024-01-01', 2, 'yashika', '3', 'Present'),
(87, '2024-01-01', 3, 'anchal', '3', 'Present'),
(88, '2024-01-02', 1, 'ishan', '1', 'Absent'),
(89, '2024-01-02', 2, 'yashika', '3', 'Present'),
(90, '2024-01-02', 3, 'anchal', '3', 'Present'),
(91, '2024-01-03', 1, 'ishan', '1', 'Present'),
(92, '2024-01-03', 2, 'yashika', '3', 'Present'),
(93, '2024-01-03', 3, 'anchal', '3', 'Present'),
(94, '2024-01-04', 1, 'ishan', '1', 'Present'),
(95, '2024-01-04', 2, 'yashika', '3', 'Absent'),
(96, '2024-01-04', 3, 'anchal', '3', 'Present'),
(97, '2024-01-05', 1, 'ishan', '1', 'Present'),
(98, '2024-01-05', 2, 'yashika', '3', 'Present'),
(99, '2024-01-05', 3, 'anchal', '3', 'Absent'),
(100, '2024-01-08', 1, 'ishan', '1', 'Present'),
(101, '2024-01-08', 2, 'yashika', '3', 'Present'),
(102, '2024-01-08', 3, 'anchal', '3', 'Present'),
(103, '2024-01-09', 1, 'ishan', '1', 'Present'),
(104, '2024-01-09', 2, 'yashika', '3', 'Present'),
(105, '2024-01-09', 3, 'anchal', '3', 'Present'),
(106, '2024-01-10', 1, 'ishan', '1', 'Present'),
(107, '2024-01-10', 2, 'yashika', '3', 'Present'),
(108, '2024-01-10', 3, 'anchal', '3', 'Present'),
(109, '2024-01-11', 1, 'ishan', '1', 'Present'),
(110, '2024-01-11', 2, 'yashika', '3', 'Present'),
(111, '2024-01-11', 3, 'anchal', '3', 'Present'),
(112, '2024-02-01', 1, 'ishan', '1', 'Present'),
(113, '2024-02-01', 2, 'yashika', '3', 'Present'),
(114, '2024-02-01', 3, 'anchal', '3', 'Present'),
(115, '2024-02-01', 4, 'yash', '2', 'Present'),
(116, '2024-02-01', 5, 'yashwant', '1', 'Present'),
(117, '2024-02-02', 1, 'ishan', '1', 'Present'),
(118, '2024-02-02', 2, 'yashika', '3', 'Present'),
(119, '2024-02-02', 3, 'anchal', '3', 'Absent'),
(120, '2024-02-02', 4, 'yash', '2', 'Present'),
(121, '2024-02-02', 5, 'yashwant', '1', 'Present'),
(122, '2024-02-05', 1, 'ishan', '1', 'Present'),
(123, '2024-02-05', 2, 'yashika', '3', 'Present'),
(124, '2024-02-05', 3, 'anchal', '3', 'Present'),
(125, '2024-02-05', 4, 'yash', '2', 'Present'),
(126, '2024-02-05', 5, 'yashwant', '1', 'Present'),
(127, '2024-02-06', 1, 'ishan', '1', 'Present'),
(128, '2024-02-06', 2, 'yashika', '3', 'Present'),
(129, '2024-02-06', 3, 'anchal', '3', 'Present'),
(130, '2024-02-06', 4, 'yash', '2', 'Present'),
(131, '2024-02-06', 5, 'yashwant', '1', 'Present'),
(132, '2024-02-07', 1, 'ishan', '1', 'Present'),
(133, '2024-02-07', 2, 'yashika', '3', 'Present'),
(134, '2024-02-07', 3, 'anchal', '3', 'Present'),
(135, '2024-02-07', 4, 'yash', '2', 'Present'),
(136, '2024-02-07', 5, 'yashwant', '1', 'Present'),
(137, '2024-02-08', 1, 'ishan', '1', 'Present'),
(138, '2024-02-08', 2, 'yashika', '3', 'Present'),
(139, '2024-02-08', 3, 'anchal', '3', 'Absent'),
(140, '2024-02-08', 4, 'yash', '2', 'Present'),
(141, '2024-02-08', 5, 'yashwant', '1', 'Present'),
(142, '2024-02-09', 1, 'ishan', '1', 'Absent'),
(143, '2024-02-09', 2, 'yashika', '3', 'Present'),
(144, '2024-02-09', 3, 'anchal', '3', 'Absent'),
(145, '2024-02-09', 4, 'yash', '2', 'Present'),
(146, '2024-02-09', 5, 'yashwant', '1', 'Present'),
(147, '2024-02-12', 1, 'ishan', '1', 'Present'),
(148, '2024-02-12', 2, 'yashika', '3', 'Present'),
(149, '2024-02-12', 3, 'anchal', '3', 'Present'),
(150, '2024-02-12', 4, 'yash', '2', 'Absent'),
(151, '2024-02-12', 5, 'yashwant', '1', 'Present'),
(152, '2024-02-13', 1, 'ishan', '1', 'Present'),
(153, '2024-02-13', 2, 'yashika', '3', 'Present'),
(154, '2024-02-13', 3, 'anchal', '3', 'Present'),
(155, '2024-02-13', 4, 'yash', '2', 'Present'),
(156, '2024-02-13', 5, 'yashwant', '1', 'Present'),
(157, '2024-02-14', 1, 'ishan', '1', 'Absent'),
(158, '2024-02-14', 2, 'yashika', '3', 'Present'),
(159, '2024-02-14', 3, 'anchal', '3', 'Present'),
(160, '2024-02-14', 4, 'yash', '2', 'Present'),
(161, '2024-02-14', 5, 'yashwant', '1', 'Present'),
(162, '2024-02-14', 6, 'avinash', '12', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `dname`) VALUES
(1, 'IT'),
(4, 'Management'),
(3, 'Marketing'),
(12, 'Quality Assurance'),
(2, 'Sales');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `des_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  `des_name` varchar(200) NOT NULL,
  `total_leaves` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`des_id`, `dept_id`, `des_name`, `total_leaves`) VALUES
(1, 1, 'Manager', 15),
(2, 1, 'Designer', 15),
(3, 1, 'Programmer', 10),
(7, 3, 'Jr Manager', 15),
(8, 3, 'Manager', 24),
(9, 2, 'Manager', 13),
(10, 4, 'Director', 25),
(11, 4, 'Joint Director', 20),
(17, 12, 'Quality Technician', 12);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `empid` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `father_name` varchar(200) NOT NULL,
  `mother_name` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `DOB` date NOT NULL,
  `qualification` varchar(200) NOT NULL,
  `experience` float(10,2) NOT NULL,
  `address` varchar(200) NOT NULL,
  `pic` varchar(200) NOT NULL,
  `id_proof_img` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `designation` int(200) NOT NULL,
  `salary` float(10,2) NOT NULL,
  `joining_date` date NOT NULL,
  `leaving_date` date NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empid`, `name`, `father_name`, `mother_name`, `phone`, `gender`, `DOB`, `qualification`, `experience`, `address`, `pic`, `id_proof_img`, `department`, `designation`, `salary`, `joining_date`, `leaving_date`, `status`) VALUES
(1, 'ishan', 'chand bhalla', 'rohini', '7897987897', 'male', '2000-02-14', 'MCA', 2.00, 'saharanpur\n', '1707909917tshirt1.jpg', '1707909925aadhaar1.jpg', '1', 1, 22600.00, '2024-01-01', '0000-00-00', 'Active'),
(2, 'yashika', 'puneet singh', 'vadhi', '8798987773', 'female', '1999-02-18', 'Btech', 2.00, 'jalandhar\n', '170790999041.jpg', '1707909994aadhaar4.jpg', '3', 7, 84000.00, '2024-01-01', '0000-00-00', 'Active'),
(3, 'anchal', 'dhruv', 'shalini', '7899879872', 'female', '2000-02-24', 'BA', 1.00, 'ludhiana\n', '1707910061aaaa.jpg', 'noimage.jpg', '3', 7, 84000.00, '2024-01-01', '0000-00-00', 'Active'),
(4, 'yash', 'ronak', 'malini', '8888999977', 'male', '1998-02-18', 'BCA', 5.00, 'jalandhar\n', 'default_user.png', 'noimage.jpg', '2', 9, 44550.00, '2024-02-01', '0000-00-00', 'Active'),
(5, 'yashwant', 'surat lal', 'usha', '77889977889', 'male', '2001-02-15', 'MCA', 5.00, 'delhi\n', 'default_user.png', 'noimage.jpg', '1', 3, 51450.00, '2024-02-01', '0000-00-00', 'Active'),
(6, 'avinash', 'rajiv', 'tamanna', '9879879877', 'male', '1996-06-06', 'MCA', 4.00, 'delhi\n', '1707910942pp.jpg', '1707910948aadhaar5.png', '12', 17, 34000.00, '2024-02-14', '0000-00-00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `manage_salary`
--

CREATE TABLE `manage_salary` (
  `department` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `total_headers` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manage_salary`
--

INSERT INTO `manage_salary` (`department`, `designation`, `total_headers`) VALUES
('1', '1', 6),
('12', '17', 3),
('1', '2', 3),
('1', '3', 2),
('3', '7', 2),
('3', '8', 3),
('2', '9', 2);

-- --------------------------------------------------------

--
-- Table structure for table `payheads`
--

CREATE TABLE `payheads` (
  `headname` varchar(100) NOT NULL,
  `headtype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payheads`
--

INSERT INTO `payheads` (`headname`, `headtype`) VALUES
('Basic Pay', 'Flat'),
('DA', 'Formula'),
('Health Insurance', 'Flat(-)'),
('HRA', 'Formula'),
('PF', 'Formula(-)'),
('TA', 'Flat');

-- --------------------------------------------------------

--
-- Table structure for table `salary_details`
--

CREATE TABLE `salary_details` (
  `srno` int(11) NOT NULL,
  `des_no` int(11) NOT NULL,
  `header` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `value_or_per` float(20,2) NOT NULL,
  `of_header` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary_details`
--

INSERT INTO `salary_details` (`srno`, `des_no`, `header`, `type`, `value_or_per`, `of_header`) VALUES
(79, 1, 'Basic Pay', 'Flat', 20000.00, '0'),
(80, 1, 'TA', 'Flat', 2000.00, '0'),
(81, 1, 'DA', 'Formula', 5.00, 'Basic Pay'),
(82, 1, 'PF', 'Formula(-)', 2.00, 'Basic Pay'),
(83, 2, 'Basic Pay', 'Flat', 35000.00, '0'),
(84, 2, 'TA', 'Flat', 5600.00, '0'),
(85, 2, 'DA', 'Formula', 2.00, 'Basic Pay'),
(86, 3, 'Basic Pay', 'Flat', 49000.00, '0'),
(87, 3, 'HRA', 'Formula', 5.00, 'Basic Pay'),
(88, 9, 'Basic Pay', 'Flat', 45000.00, '0'),
(89, 9, 'PF', 'Formula(-)', 1.00, 'Basic Pay'),
(90, 7, 'Basic Pay', 'Flat', 89000.00, '0'),
(91, 7, 'Health Insurance', 'Flat(-)', 5000.00, '0'),
(92, 8, 'Basic Pay', 'Flat', 98000.00, '0'),
(93, 8, 'TA', 'Flat', 10000.00, '0'),
(94, 8, 'DA', 'Formula', 3.00, 'Basic Pay'),
(95, 17, 'Basic Pay', 'Flat', 30000.00, '0'),
(96, 17, 'TA', 'Flat', 2500.00, '0'),
(97, 17, 'DA', 'Formula', 5.00, 'Basic Pay'),
(98, 1, 'Health Insurance', 'Flat(-)', 500.00, '0'),
(99, 1, 'HRA', 'Formula', 2.00, 'Basic Pay');

-- --------------------------------------------------------

--
-- Table structure for table `salary_table`
--

CREATE TABLE `salary_table` (
  `srno` int(10) NOT NULL,
  `year` int(10) NOT NULL,
  `month` int(10) NOT NULL,
  `payment_date` date NOT NULL,
  `empid` int(20) NOT NULL,
  `basic_salary` float(10,2) NOT NULL,
  `Absent_days` int(10) NOT NULL,
  `paid_leaves` int(10) NOT NULL,
  `absent_fine` float(10,2) NOT NULL,
  `bonus` float(10,2) NOT NULL,
  `bonus_reason` varchar(100) NOT NULL,
  `net_salary` float(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary_table`
--

INSERT INTO `salary_table` (`srno`, `year`, `month`, `payment_date`, `empid`, `basic_salary`, `Absent_days`, `paid_leaves`, `absent_fine`, `bonus`, `bonus_reason`, `net_salary`) VALUES
(9, 2024, 1, '2024-01-31', 1, 22600.00, 1, 0, 729.00, 0.00, '\n', 21870.00),
(10, 2024, 1, '2024-01-31', 2, 84000.00, 1, 0, 2709.00, 100.00, 'overtime\n\n', 81390.00),
(11, 2024, 1, '2024-01-31', 3, 84000.00, 1, 0, 2709.00, 0.00, '\n', 81290.00),
(12, 2024, 2, '2024-02-14', 1, 22600.00, 2, 0, 1558.00, 0.00, '\n', 21041.00),
(13, 2024, 2, '2024-02-14', 3, 84000.00, 3, 0, 8689.00, 1000.00, 'overtime\n', 76310.00),
(14, 2024, 2, '2024-02-14', 1, 22600.00, 2, 0, 1558.00, 0.00, '\n\n', 21041.00);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`username`, `password`, `usertype`) VALUES
('admin', '22', 'Admin'),
('sonia', '123', 'Front Desk Executive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendancetable`
--
ALTER TABLE `attendancetable`
  ADD PRIMARY KEY (`srno`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`),
  ADD UNIQUE KEY `dname` (`dname`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`des_id`),
  ADD KEY `const1` (`dept_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`empid`),
  ADD KEY `designation` (`designation`);

--
-- Indexes for table `manage_salary`
--
ALTER TABLE `manage_salary`
  ADD PRIMARY KEY (`designation`);

--
-- Indexes for table `payheads`
--
ALTER TABLE `payheads`
  ADD PRIMARY KEY (`headname`);

--
-- Indexes for table `salary_details`
--
ALTER TABLE `salary_details`
  ADD PRIMARY KEY (`srno`),
  ADD KEY `des_no` (`des_no`);

--
-- Indexes for table `salary_table`
--
ALTER TABLE `salary_table`
  ADD PRIMARY KEY (`srno`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendancetable`
--
ALTER TABLE `attendancetable`
  MODIFY `srno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `des_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `empid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `salary_details`
--
ALTER TABLE `salary_details`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `salary_table`
--
ALTER TABLE `salary_table`
  MODIFY `srno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `designation`
--
ALTER TABLE `designation`
  ADD CONSTRAINT `const1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `const2` FOREIGN KEY (`designation`) REFERENCES `designation` (`des_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
