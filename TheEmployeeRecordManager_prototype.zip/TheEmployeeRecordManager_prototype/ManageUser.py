from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Treeview, Combobox
import pymysql
import detailspage as dp

class ManageUserClass:
    def __init__(self,pwindow):
        self.window=pwindow

        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()

        #------------- Making widgets --------------
        self.headlbl=Label(self.window,text="Manage User",font=dp.myheadfont,background=dp.all_pages_bk)

        self.l1=Label(self.window,text='User Name',font=dp.mynormalfont,background=dp.all_pages_bk)
        self.l2=Label(self.window,text='Password',font=dp.mynormalfont,background=dp.all_pages_bk)
        self.l3=Label(self.window,text='User Type',font=dp.mynormalfont,background=dp.all_pages_bk)

        self.t1=Entry(self.window,font=dp.mynormalfont)
        self.t2=Entry(self.window,font=dp.mynormalfont,show='*')
        self.v1 = StringVar()
        self.c1 = Combobox(self.window,values=('Admin','Front Desk Executive'), state="readonly",
                textvariable=self.v1,font=dp.mynormalfont)


        #--------table----------
        if (w >= 1600):
            t_height=15
            t_w=300
        elif (w >= 1300):
            t_height=10
            t_w=250
        else:   #(w >= 1280):
            t_height=10
            t_w=150

        self.tablearea = Frame(self.window )
        scrollbarx = Scrollbar(self.tablearea, orient=HORIZONTAL)
        scrollbary = Scrollbar(self.tablearea, orient=VERTICAL)
        self.mytable = Treeview(self.tablearea,height=t_height,columns=['a','b'],
                        yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
        scrollbarx.config(command=self.mytable.xview)
        scrollbarx.pack(side=BOTTOM, fill=X)
        scrollbary.config(command=self.mytable.yview)
        scrollbary.pack(side=RIGHT, fill=Y)
        self.mytable.heading('a',text='UserName')
        self.mytable.heading('b',text='UserType')
        self.mytable['show']='headings'
        self.mytable.column("#1", width=t_w, anchor='center')
        self.mytable.column("#2", width=t_w, anchor='center')
        self.mytable.pack()
        self.mytable.bind('<ButtonRelease-1>',lambda e : self.getpk())


        #------ buttons---------
        self.b1=Button(self.window,text='Save',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.savedata)
        self.b2=Button(self.window,text='Update',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.updatedata)
        self.b3=Button(self.window,text='Delete',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.deletedata)
        self.b4=Button(self.window,text='Search',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.fetchalldata)
        self.b5=Button(self.window,text='Reset',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.clearpage)
        self.b6=Button(self.window,text='Back',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.go_back)
        self.b7=Button(self.window,text='Fetch',font=dp.mynormalfont,background=dp.all_btn_bk_color,foreground=dp.all_btn_fg_color,command=self.fetchdata)


        #---------------placements-----------------
        if (w >= 1600):
            x1 = 160
            y1 = 100
            ydiff = 45
            xdiff = 150
            wigdet_width = 200
            t_diff = xdiff + xdiff + xdiff + xdiff
            upper_btn_x = x1 + xdiff + xdiff + 55
            btn_low_width = 120
        else:
            x1 = 160
            y1 = 100
            ydiff = 45
            xdiff = 150
            wigdet_width = 200
            t_diff = xdiff + xdiff + xdiff + xdiff-40
            upper_btn_x = x1 + xdiff + xdiff + 55
            btn_low_width = 120

        self.headlbl.place(x=400,y=5)

        self.l1.place(x=x1,y=y1)
        self.t1.place(x=x1+xdiff,y=y1,width=wigdet_width)
        self.b7.place(x=upper_btn_x,y=y1,width=wigdet_width-100,height=30)
        self.tablearea.place(x=x1+t_diff, y=y1)
        y1 += ydiff
        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1+xdiff,y=y1,width=wigdet_width)
        y1 += ydiff
        self.l3.place(x=x1,y=y1)
        self.c1.place(x=x1+xdiff,y=y1,width=wigdet_width)
        self.b4.place(x=upper_btn_x,y=y1,width=wigdet_width-100,height=30)
        y1 += ydiff
        y1 += ydiff
        self.b3.place(x=x1 ,y=y1,width=btn_low_width)
        self.b2.place(x=x1+btn_low_width*1+10,y=y1,width=btn_low_width)
        self.b1.place(x=x1+btn_low_width*2+20,y=y1,width=btn_low_width)
        y1 += ydiff
        self.b6.place(x=x1+(btn_low_width/2),y=y1,width=btn_low_width)
        self.b5.place(x=x1+(btn_low_width/2)+btn_low_width*1+10,y=y1,width=btn_low_width)

        self.clearpage()
        self.window.mainloop()

    def go_back(self):
        f4 = self.window
        f4.place_forget()
        myMainWindow = f4.master
        w_list = myMainWindow.winfo_children()
        w_list[-1].place_forget()

    def databaseconnection(self):
        try:
            self.conn = pymysql.connect(host=dp.myhost,db=dp.mydb,user=dp.myuser,password=dp.mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error","Error while connecting with database\n\n"+str(e),parent=self.window)

    def savedata(self):
        # username	password	usertype
        if (self.validate_check()):

            self.databaseconnection()
            try:
                myqry='insert into usertable values(%s,%s,%s)'
                row_count=self.curr.execute(myqry,(self.t1.get(),self.t2.get(),self.v1.get()))
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Success", "User Added Successfully",parent=self.window)
                    self.clearpage()
                else:
                    messagebox.showinfo("Unsuccessful", "Record not inserted ", parent=self.window)
            except Exception as e:
                messagebox.showerror("Query Error","Error while Insertion of record\n\n"+str(e),parent=self.window)

    def updatedata(self):
        if (self.validate_check()):
            self.databaseconnection()
            try:
                #username	password	usertype
                myqry='update usertable set password=%s, usertype=%s  where username =%s'
                row_count=self.curr.execute(myqry,( self.t2.get() ,self.v1.get(), self.t1.get()))
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Success", "User Record Updated Successfully",parent=self.window)
                    self.clearpage()
                else:
                    messagebox.showinfo("UnSuccessful", "Record not Updated", parent=self.window)
            except Exception as e:
                messagebox.showerror("Query Error","Error while Updating record\n\n"+str(e),parent=self.window)

    def deletedata(self):
        ans = messagebox.askquestion("Confirmation","Are you sure to Delete ? ",parent=self.window)
        if ans=='yes':
            self.databaseconnection()
            try:
                myqry='delete from usertable where username= %s'
                row_count=self.curr.execute(myqry,( self.t1.get()))
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Success", "User Record deleted Successfully",parent=self.window)
                    self.clearpage()
                else:
                    messagebox.showinfo("UnSuccessful", "Record not Deleted", parent=self.window)
            except Exception as e:
                messagebox.showerror("Query Error","Error while Deletion of record\n\n"+str(e),parent=self.window)

    def getpk(self):
        id =  self.mytable.focus()
        content = self.mytable.item(id)
        myvalues = content['values']
        pk = myvalues[0]
        self.fetchdata(pk)

    def fetchdata(self,pk=None):
        if pk==None:
            mypk=self.t1.get()
        else:
            mypk=pk
        self.databaseconnection()
        try:
            #cid	cname	price
            myqry='select * from usertable where username = %s'
            self.curr.execute(myqry,(mypk))
            data = self.curr.fetchone()
            self.clearpage()
            if data:
                self.t1.insert(0,data[0])
                self.t2.insert(0,data[1])
                self.v1.set(data[2])

                self.b2['state'] = 'normal'
                self.b3['state'] = 'normal'

        except Exception as e:
            messagebox.showerror("Query Error","Error while fetching query "+str(e),parent=self.window)

    def clearpage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.v1.set("Choose Usertype")

        self.b2['state'] = 'disabled'
        self.b3['state'] = 'disabled'
        self.fetchalldata()

    def fetchalldata(self):
        self.databaseconnection()
        try:
            if self.v1.get()=='Choose Usertype':
                ut=''
            else:
                ut=self.v1.get()
            myqry='select * from usertable  where usertype like %s'
            self.curr.execute(myqry ,(ut+"%"))
            data = self.curr.fetchall()
            self.mytable.delete(*self.mytable.get_children())

            if data:
               count = 2
               for row in data:
                   d1 = [row[0],row[2]]
                   if count % 2 == 0:
                       self.mytable.insert('', END, values=d1, tag='even')
                   else:
                       self.mytable.insert('', END, values=d1, tag='odd')
                   count += 1
               self.mytable.tag_configure('even', background=dp.table_row_bk_color1, foreground=dp.table_row_fg_color1)
               self.mytable.tag_configure('odd', background=dp.table_row_bk_color2,foreground=dp.table_row_fg_color2)
            else:
                messagebox.showwarning("No record", "No Record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error","Error while Searching of record\n\n"+str(e),parent=self.window)

    def validate_check(self):
        if  len(self.t1.get())<2:
            messagebox.showwarning("Validation Check", "Please Enter Name ", parent=self.window)
            return False
        elif self.t2.get() =="" :
            messagebox.showwarning("Validation Check", "Please EnterPassword", parent=self.window)
            return False
        elif self.v1.get() == "Choose Usertype":
            messagebox.showwarning("Validation Check", "Please Choose User type", parent=self.window)
            return False
        return True

if __name__ == '__main__':
    window = Tk()
    window.title(dp.app_title_name)
    w = window.winfo_screenwidth()
    h = window.winfo_screenheight()
    window.geometry("%dx%d+%d+%d" % (w -200, h-100, 100,50))
    f3 = Frame(window, background=dp.my_color1)  # content pane
    f3.place(x=0, y=0, height=h - 100, width=w - 200)  # content pane
    ManageUserClass(f3)
    window.mainloop()